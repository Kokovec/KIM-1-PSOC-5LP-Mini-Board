/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
//#include <FS.h>
#include <stdio.h>
//#include <stdint.h>
#include <string.h>
//#include <stdlib.h>
//#include <math.h>

void Display_UART_Config();
void TxWaitForCharUART();

uint8 const ROM[] = 
{
    0xa9,0xad,0x8d,0xec,0x17,0x20,0x32,0x19,0xa9,0x27,0x8d,0x42,0x17,0xa9,0xbf,0x8d, 
    0x43,0x17,0xa2,0x64,0xa9,0x16,0x20,0x7a,0x19,0xca,0xd0,0xf8,0xa9,0x2a,0x20,0x7a, 
    0x19,0xad,0xf9,0x17,0x20,0x61,0x19,0xad,0xf5,0x17,0x20,0x5e,0x19,0xad,0xf6,0x17, 
    0x20,0x5e,0x19,0xad,0xed,0x17,0xcd,0xf7,0x17,0xad,0xee,0x17,0xed,0xf8,0x17,0x90, 
    0x24,0xa9,0x2f,0x20,0x7a,0x19,0xad,0xe7,0x17,0x20,0x61,0x19,0xad,0xe8,0x17,0x20,
    0x61,0x19,0xa2,0x02,0xa9,0x04,0x20,0x7a,0x19,0xca,0xd0,0xf8,0xa9,0x00,0x85,0xfa, 
    0x85,0xfb,0x4c,0x4f,0x1c,0x20,0xec,0x17,0x20,0x5e,0x19,0x20,0xea,0x19,0x4c,0x33, 
    0x18,0x0f,0x19,0xa9,0x8d,0x8d,0xec,0x17,0x20,0x32,0x19,0xa9,0x4c,0x8d,0xef,0x17, 
    0xad,0x71,0x18,0x8d,0xf0,0x17,0xad,0x72,0x18,0x8d,0xf1,0x17,0xa9,0x07,0x8d,0x42, 
    0x17,0xa9,0xff,0x8d,0xe9,0x17,0x20,0x41,0x1a,0x4e,0xe9,0x17,0x0d,0xe9,0x17,0x8d,
    0xe9,0x17,0xad,0xe9,0x17,0xc9,0x16,0xd0,0xed,0xa2,0x0a,0x20,0x24,0x1a,0xc9,0x16, 
    0xd0,0xdf,0xca,0xd0,0xf6,0x20,0x24,0x1a,0xc9,0x2a,0xf0,0x06,0xc9,0x16,0xd0,0xd1, 
    0xf0,0xf3,0x20,0xf3,0x19,0xcd,0xf9,0x17,0xf0,0x0d,0xad,0xf9,0x17,0xc9,0x00,0xf0, 
    0x06,0xc9,0xff,0xf0,0x17,0xd0,0x9c,0x20,0xf3,0x19,0x20,0x4c,0x19,0x8d,0xed,0x17, 
    0x20,0xf3,0x19,0x20,0x4c,0x19,0x8d,0xee,0x17,0x4c,0xf8,0x18,0x20,0xf3,0x19,0x20, 
    0x4c,0x19,0x20,0xf3,0x19,0x20,0x4c,0x19,0xa2,0x02,0x20,0x24,0x1a,0xc9,0x2f,0xf0, 
    0x14,0x20,0x00,0x1a,0xd0,0x23,0xca,0xd0,0xf1,0x20,0x4c,0x19,0x4c,0xec,0x17,0x20, 
    0xea,0x19,0x4c,0xf8,0x18,0x20,0xf3,0x19,0xcd,0xe7,0x17,0xd0,0x0c,0x20,0xf3,0x19, 
    0xcd,0xe8,0x17,0xd0,0x04,0xa9,0x00,0xf0,0x02,0xa9,0xff,0x85,0xfa,0x85,0xfb,0x4c, 
    0x4f,0x1c,0xad,0xf5,0x17,0x8d,0xed,0x17,0xad,0xf6,0x17,0x8d,0xee,0x17,0xa9,0x60, 
    0x8d,0xef,0x17,0xa9,0x00,0x8d,0xe7,0x17,0x8d,0xe8,0x17,0x60,0xa8,0x18,0x6d,0xe7, 
    0x17,0x8d,0xe7,0x17,0xad,0xe8,0x17,0x69,0x00,0x8d,0xe8,0x17,0x98,0x60,0x20,0x4c, 
    0x19,0xa8,0x4a,0x4a,0x4a,0x4a,0x20,0x6f,0x19,0x98,0x20,0x6f,0x19,0x98,0x60,0x29, 
    0x0f,0xc9,0x0a,0x18,0x30,0x02,0x69,0x07,0x69,0x30,0x8e,0xe9,0x17,0x8c,0xea,0x17, 
    0xa0,0x08,0x20,0x9e,0x19,0x4a,0xb0,0x06,0x20,0x9e,0x19,0x4c,0x91,0x19,0x20,0xc4, 
    0x19,0x20,0xc4,0x19,0x88,0xd0,0xeb,0xae,0xe9,0x17,0xac,0xea,0x17,0x60,0xa2,0x09, 
    0x48,0x2c,0x47,0x17,0x10,0xfb,0xa9,0x7e,0x8d,0x44,0x17,0xa9,0xa7,0x8d,0x42,0x17, 
    0x2c,0x47,0x17,0x10,0xfb,0xa9,0x7e,0x8d,0x44,0x17,0xa9,0x27,0x8d,0x42,0x17,0xca, 
    0xd0,0xdf,0x68,0x60,0xa2,0x06,0x48,0x2c,0x47,0x17,0x10,0xfb,0xa9,0xc3,0x8d,0x44, 
    0x17,0xa9,0xa7,0x8d,0x42,0x17,0x2c,0x47,0x17,0x10,0xfb,0xa9,0xc3,0x8d,0x44,0x17, 
    0xa9,0x27,0x8d,0x42,0x17,0xca,0xd0,0xdf,0x68,0x60,0xee,0xed,0x17,0xd0,0x03,0xee, 
    0xee,0x17,0x60,0x20,0x24,0x1a,0x20,0x00,0x1a,0x20,0x24,0x1a,0x20,0x00,0x1a,0x60, 
    0xc9,0x30,0x30,0x1e,0xc9,0x47,0x10,0x1a,0xc9,0x40,0x30,0x03,0x18,0x69,0x09,0x2a, 
    0x2a,0x2a,0x2a,0xa0,0x04,0x2a,0x2e,0xe9,0x17,0x88,0xd0,0xf9,0xad,0xe9,0x17,0xa0, 
    0x00,0x60,0xc8,0x60,0x8e,0xeb,0x17,0xa2,0x08,0x20,0x41,0x1a,0x4e,0xea,0x17,0x0d, 
    0xea,0x17,0x8d,0xea,0x17,0xca,0xd0,0xf1,0xad,0xea,0x17,0x2a,0x4a,0xae,0xeb,0x17, 
    0x60,0x2c,0x42,0x17,0x10,0xfb,0xad,0x46,0x17,0xa0,0xff,0x8c,0x46,0x17,0xa0,0x14, 
    0x88,0xd0,0xfd,0x2c,0x42,0x17,0x30,0xfb,0x38,0xed,0x46,0x17,0xa0,0xff,0x8c,0x46, 
    0x17,0xa0,0x07,0x88,0xd0,0xfd,0x49,0xff,0x29,0x80,0x60,0xa9,0x27,0x8d,0x42,0x17, 
    0xa9,0xbf,0x8d,0x43,0x17,0x2c,0x47,0x17,0x10,0xfb,0xa9,0x9a,0x8d,0x44,0x17,0xa9, 
    0xa7,0x8d,0x42,0x17,0x2c,0x47,0x17,0x10,0xfb,0xa9,0x9a,0x8d,0x44,0x17,0xa9,0x27, 
    0x8d,0x42,0x17,0x4c,0x75,0x1a,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x6b,0x1a,0x6b,0x1a,0x6b,0x1a, 
    0x85,0xf3,0x68,0x85,0xf1,0x68,0x85,0xef,0x85,0xfa,0x68,0x85,0xf0,0x85,0xfb,0x84, 
    0xf4,0x86,0xf5,0xba,0x86,0xf2,0x20,0x88,0x1e,0x4c,0x4f,0x1c,0x6c,0xfa,0x17,0x6c, 
    0xfe,0x17,0xa2,0xff,0x9a,0x86,0xf2,0x20,0x88,0x1e,0xa9,0xff,0x8d,0xf3,0x17,0xa9, 
    0x01,0x2c,0x40,0x17,0x4c,0x4f,0x1c,0xea,0xa9,0xfc,0x18,0x69,0x01,0x90,0x03,0xee, 
    0xf3,0x17,0xac,0x40,0x17,0x10,0xf3,0x8d,0xf2,0x17,0xa2,0x08,0x20,0x6a,0x1e,0x20, 
    0x8c,0x1e,0xa9,0x01,0x2c,0x40,0x17,0xd0,0x1e,0x20,0x2f,0x1e,0xa2,0x0a,0x20,0x31, 
    0x1e,0x4c,0xaf,0x1d,0xa9,0x00,0x85,0xf8,0x85,0xf9,0x20,0x5a,0x1e,0xc9,0x01,0xf0, 
    0x06,0x20,0xac,0x1f,0x4c,0xdb,0x1d,0x20,0x19,0x1f,0xd0,0xd3,0xa9,0x01,0x2c,0x40, 
    0x17,0xf0,0xcc,0x20,0x19,0x1f,0xf0,0xf4,0x20,0x19,0x1f,0xf0,0xef,0x20,0x6a,0x1f, 
    0xc9,0x15,0x10,0xbb,0xc9,0x14,0xf0,0x44,0xc9,0x10,0xf0,0x2c,0xc9,0x11,0xf0,0x2c, 
    0xc9,0x12,0xf0,0x2f,0xc9,0x13,0xf0,0x31,0x0a,0x0a,0x0a,0x0a,0x85,0xfc,0xa2,0x04, 
    0xa4,0xff,0xd0,0x0a,0xb1,0xfa,0x06,0xfc,0x2a,0x91,0xfa,0x4c,0xc3,0x1c,0x0a,0x26, 
    0xfa,0x26,0xfb,0xca,0xd0,0xea,0xf0,0x08,0xa9,0x01,0xd0,0x02,0xa9,0x00,0x85,0xff, 
    0x4c,0x4f,0x1c,0x20,0x63,0x1f,0x4c,0x4f,0x1c,0x4c,0xc8,0x1d,0xa5,0xef,0x85,0xfa, 
    0xa5,0xf0,0x85,0xfb,0x4c,0x4f,0x1c,0x20,0x5a,0x1e,0xc9,0x3b,0xd0,0xf9,0xa9,0x00, 
    0x85,0xf7,0x85,0xf6,0x20,0x9d,0x1f,0xaa,0x20,0x91,0x1f,0x20,0x9d,0x1f,0x85,0xfb, 
    0x20,0x91,0x1f,0x20,0x9d,0x1f,0x85,0xfa,0x20,0x91,0x1f,0x8a,0xf0,0x0f,0x20,0x9d, 
    0x1f,0x91,0xfa,0x20,0x91,0x1f,0x20,0x63,0x1f,0xca,0xd0,0xf2,0xe8,0x20,0x9d,0x1f, 
    0xc5,0xf6,0xd0,0x17,0x20,0x9d,0x1f,0xc5,0xf7,0xd0,0x13,0x8a,0xd0,0xb9,0xa2,0x0c, 
    0xa9,0x27,0x8d,0x42,0x17,0x20,0x31,0x1e,0x4c,0x4f,0x1c,0x20,0x9d,0x1f,0xa2,0x11, 
    0xd0,0xee,0xa9,0x00,0x85,0xf8,0x85,0xf9,0xa9,0x00,0x85,0xf6,0x85,0xf7,0x20,0x2f, 
    0x1e,0xa9,0x3b,0x20,0xa0,0x1e,0xa5,0xfa,0xcd,0xf7,0x17,0xa5,0xfb,0xed,0xf8,0x17, 
    0x90,0x18,0xa9,0x00,0x20,0x3b,0x1e,0x20,0xcc,0x1f,0x20,0x1e,0x1e,0xa5,0xf6,0x20, 
    0x3b,0x1e,0xa5,0xf7,0x20,0x3b,0x1e,0x4c,0x64,0x1c,0xa9,0x18,0xaa,0x20,0x3b,0x1e, 
    0x20,0x91,0x1f,0x20,0x1e,0x1e,0xa0,0x00,0xb1,0xfa,0x20,0x3b,0x1e,0x20,0x91,0x1f, 
    0x20,0x63,0x1f,0xca,0xd0,0xf0,0xa5,0xf6,0x20,0x3b,0x1e,0xa5,0xf7,0x20,0x3b,0x1e, 
    0xe6,0xf8,0xd0,0x02,0xe6,0xf9,0x4c,0x48,0x1d,0x20,0xcc,0x1f,0x20,0x2f,0x1e,0x20, 
    0x1e,0x1e,0x20,0x9e,0x1e,0xa0,0x00,0xb1,0xfa,0x20,0x3b,0x1e,0x20,0x9e,0x1e,0x4c, 
    0x64,0x1c,0x20,0x63,0x1f,0x4c,0xac,0x1d,0xa6,0xf2,0x9a,0xa5,0xfb,0x48,0xa5,0xfa, 
    0x48,0xa5,0xf1,0x48,0xa6,0xf5,0xa4,0xf4,0xa5,0xf3,0x40,0xc9,0x20,0xf0,0xca,0xc9, 
    0x7f,0xf0,0x1b,0xc9,0x0d,0xf0,0xdb,0xc9,0x0a,0xf0,0x1c,0xc9,0x2e,0xf0,0x26,0xc9, 
    0x47,0xf0,0xd5,0xc9,0x51,0xf0,0x0a,0xc9,0x4c,0xf0,0x09,0x4c,0x6a,0x1c,0x4c,0x4f, 
    0x1c,0x4c,0x42,0x1d,0x4c,0xe7,0x1c,0x38,0xa5,0xfa,0xe9,0x01,0x85,0xfa,0xb0,0x02, 
    0xc6,0xfb,0x4c,0xac,0x1d,0xa0,0x00,0xa5,0xf8,0x91,0xfa,0x4c,0xc2,0x1d,0xa5,0xfb, 
    0x20,0x3b,0x1e,0x20,0x91,0x1f,0xa5,0xfa,0x20,0x3b,0x1e,0x20,0x91,0x1f,0x60,0xa2, 
    0x07,0xbd,0xd5,0x1f,0x20,0xa0,0x1e,0xca,0x10,0xf7,0x60,0x85,0xfc,0x4a,0x4a,0x4a, 
    0x4a,0x20,0x4c,0x1e,0xa5,0xfc,0x20,0x4c,0x1e,0xa5,0xfc,0x60,0x29,0x0f,0xc9,0x0a, 
    0x18,0x30,0x02,0x69,0x07,0x69,0x30,0x4c,0xa0,0x1e,0x86,0xfd,0xa2,0x08,0xa9,0x01, 
    0x2c,0x40,0x17,0xd0,0x22,0x30,0xf9,0x20,0xd4,0x1e,0x20,0xeb,0x1e,0xad,0x40,0x17, 
    0x29,0x80,0x46,0xfe,0x05,0xfe,0x85,0xfe,0x20,0xd4,0x1e,0xca,0xd0,0xef,0x20,0xeb, 
    0x1e,0xa6,0xfd,0xa5,0xfe,0x2a,0x4a,0x60,0xa2,0x01,0x86,0xff,0xa2,0x00,0x8e,0x41, 
    0x17,0xa2,0x3f,0x8e,0x43,0x17,0xa2,0x07,0x8e,0x42,0x17,0xd8,0x78,0x60,0xa9,0x20, 
    0x85,0xfe,0x86,0xfd,0x20,0xd4,0x1e,0xad,0x42,0x17,0x29,0xfe,0x8d,0x42,0x17,0x20, 
    0xd4,0x1e,0xa2,0x08,0xad,0x42,0x17,0x29,0xfe,0x46,0xfe,0x69,0x00,0x8d,0x42,0x17, 
    0x20,0xd4,0x1e,0xca,0xd0,0xee,0xad,0x42,0x17,0x09,0x01,0x8d,0x42,0x17,0x20,0xd4, 
    0x1e,0xa6,0xfd,0x60,0xad,0xf3,0x17,0x8d,0xf4,0x17,0xad,0xf2,0x17,0x38,0xe9,0x01, 
    0xb0,0x03,0xce,0xf4,0x17,0xac,0xf4,0x17,0x10,0xf3,0x60,0xad,0xf3,0x17,0x8d,0xf4, 
    0x17,0xad,0xf2,0x17,0x4a,0x4e,0xf4,0x17,0x90,0xe3,0x09,0x80,0xb0,0xe0,0xa0,0x03, 
    0xa2,0x01,0xa9,0xff,0x8e,0x42,0x17,0xe8,0xe8,0x2d,0x40,0x17,0x88,0xd0,0xf5,0xa0, 
    0x07,0x8c,0x42,0x17,0x09,0x80,0x49,0xff,0x60,0xa0,0x00,0xb1,0xfa,0x85,0xf9,0xa9, 
    0x7f,0x8d,0x41,0x17,0xa2,0x09,0xa0,0x03,0xb9,0xf8,0x00,0x4a,0x4a,0x4a,0x4a,0x20, 
    0x48,0x1f,0xb9,0xf8,0x00,0x29,0x0f,0x20,0x48,0x1f,0x88,0xd0,0xeb,0x8e,0x42,0x17, 
    0xa9,0x00,0x8d,0x41,0x17,0x4c,0xfe,0x1e,0x84,0xfc,0xa8,0xb9,0xe7,0x1f,0xa0,0x00, 
    0x8c,0x40,0x17,0x8e,0x42,0x17,0x8d,0x40,0x17,0xa0,0x7f,0x88,0xd0,0xfd,0xe8,0xe8, 
    0xa4,0xfc,0x60,0xe6,0xfa,0xd0,0x02,0xe6,0xfb,0x60,0xa2,0x21,0xa0,0x01,0x20,0x02, 
    0x1f,0xd0,0x07,0xe0,0x27,0xd0,0xf5,0xa9,0x15,0x60,0xa0,0xff,0x0a,0xb0,0x03,0xc8, 
    0x10,0xfa,0x8a,0x29,0x0f,0x4a,0xaa,0x98,0x10,0x03,0x18,0x69,0x07,0xca,0xd0,0xfa, 
    0x60,0x18,0x65,0xf7,0x85,0xf7,0xa5,0xf6,0x69,0x00,0x85,0xf6,0x60,0x20,0x5a,0x1e, 
    0x20,0xac,0x1f,0x20,0x5a,0x1e,0x20,0xac,0x1f,0xa5,0xf8,0x60,0xc9,0x30,0x30,0x1b, 
    0xc9,0x47,0x10,0x17,0xc9,0x40,0x30,0x03,0x18,0x69,0x09,0x2a,0x2a,0x2a,0x2a,0xa0, 
    0x04,0x2a,0x26,0xf8,0x26,0xf9,0x88,0xd0,0xf8,0xa9,0x00,0x60,0xa5,0xf8,0x85,0xfa, 
    0xa5,0xf9,0x85,0xfb,0x60,0x00,0x00,0x00,0x00,0x00,0x00,0x0a,0x0d,0x4d,0x49,0x4b, 
    0x20,0x13,0x52,0x52,0x45,0x20,0x13,0xbf,0x86,0xdb,0xcf,0xe6,0xed,0xfd,0x87,0xff, 
    0xef,0xf7,0xfc,0xb9,0xde,0xf9,0xf1,0x00,0x00,0x00,0x1c,0x1c,0x22,0x1c,0x1f,0x1c
};

// Reserve 5K for RAM ($0000-$13FF)
uint8 RAM_User[5120] = {};

// Reserve RAM for 6530_002/3 ($1780-$17FF)
uint8 RAM_6530[128] = {};

// Reserve RAM for KIM expansion
uint8 RAM_User_Expand[32*1024] = {};


struct RIOT {
    uint8 SAD;      // $1700/$1740           6530 A DATA
    uint8 PADD;     // $1701/$1741           6530 A DATA DIRECTION
    uint8 SBD;      // $1702/$1742           6530 B DATA
    uint8 PBDD;     // $1703/$1743           6530 B DATA DIRECTION
    uint8 CLK1T;    // $1704/$1744           DIV BY 1 TIME (no int)
    uint8 CLK8T;    // $1705/$1745           DIV BY 8 TIME (no int)
    uint8 CLK64T;   // $1706/$1746           DIV BY 64 TIME (no int)
    uint8 CLKKT;    // $1707/$1747           DIV BY 1024 TIME (no int)
    uint8 CLKRDI;   // $1707/$1747           READ TIME OUT BIT
                    // bit 7 set to 1 if timer passed 0 (TC)
    uint8 CLKRDT;   // $1706/$1746           READ TIME, actual value of the timer
    uint8 PCLK;     // Flag: previous clock divider setting
                    // clock div reverts to 1 after passed 0 (TC)
                    // read to $1706/$1746 reverts div to previous pgm rate
    uint8 fCHANGE;  // State change flag: 0 = no change, 1 = change
                    // Flag is set if CLK mem locations are written / read
};

struct RIOT RIOT_002;
struct RIOT RIOT_003;

uint8 speedflag = 0;

// 7-Segment Display Characters (A-Z)
uint8 const Display_Chars[] = {0x77,0x1F,0x39,0x3D,0x4F,0x71,0x3D,0x37,0x30,0x3C,0x37,
                               0x0E,0x55,0x54,0x5C,0x67,0x73,0x50,0x5B,0x78,0x3E,0x27,
                               0x3F,0x25,0x3B,0x6D};

// UART Config Message
char const UART_Message[] = "UART CONFIG";

/*
 * Fake6502 used to similate the 6502 micro
 *
 * https://github.com/hrvach/espple/blob/master/user/fake6502.c
 *
*/
//6502 defines
// #define UNDOCUMENTED //when this is defined, undocumented opcodes are handled.
                        //otherwise, they're simply treated as NOPs.

// #define NES_CPU      //when this is defined, the binary-coded decimal (BCD)
                     //status flag is not honored by ADC and SBC. the 2A03
                     //CPU in the Nintendo Entertainment System does not
                     //support BCD operation.

#define FLAG_CARRY     0x01
#define FLAG_ZERO      0x02
#define FLAG_INTERRUPT 0x04
#define FLAG_DECIMAL   0x08
#define FLAG_BREAK     0x10
#define FLAG_CONSTANT  0x20
#define FLAG_OVERFLOW  0x40
#define FLAG_SIGN      0x80

#define BASE_STACK     0x100

#define saveaccum(n) a = (uint8_t)((n) & 0x00FF)


//flag modifier macros
#define setcarry() status |= FLAG_CARRY
#define clearcarry() status &= (~FLAG_CARRY)
#define setzero() status |= FLAG_ZERO
#define clearzero() status &= (~FLAG_ZERO)
#define setinterrupt() status |= FLAG_INTERRUPT
#define clearinterrupt() status &= (~FLAG_INTERRUPT)
#define setdecimal() status |= FLAG_DECIMAL
#define cleardecimal() status &= (~FLAG_DECIMAL)
#define setoverflow() status |= FLAG_OVERFLOW
#define clearoverflow() status &= (~FLAG_OVERFLOW)
#define setsign() status |= FLAG_SIGN
#define clearsign() status &= (~FLAG_SIGN)


//flag calculation macros
#define zerocalc(n) {\
    if ((n) & 0x00FF) clearzero();\
        else setzero();\
}

#define signcalc(n) {\
    if ((n) & 0x0080) setsign();\
        else clearsign();\
}

#define carrycalc(n) {\
    if ((n) & 0xFF00) setcarry();\
        else clearcarry();\
}

#define overflowcalc(n, m, o) { /* n = result, m = accumulator, o = memory */ \
    if (((n) ^ (uint16_t)(m)) & ((n) ^ (o)) & 0x0080) setoverflow();\
        else clearoverflow();\
}


//6502 CPU registers
uint16_t pc;
uint8_t sp, a, x, y, status;
// BCD fix OV 20140915 - helper variables for adc and sbc
uint16_t lxx,hxx;
// end of BCD fix part 1


//helper variables
uint32_t clockticks6502 = 0, clockgoal6502 = 0;
uint16_t oldpc, ea, reladdr, value, result;
uint8_t opcode, oldstatus;

//externally supplied functions
extern uint8_t read6502(uint16_t address);
extern void write6502(uint16_t address, uint8_t value);

//a few general functions used by various other functions
void push16(uint16_t pushval) {
    write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
    write6502(BASE_STACK + ((sp - 1) & 0xFF), pushval & 0xFF);
    sp -= 2;
}

void push8(uint8_t pushval) {
    write6502(BASE_STACK + sp--, pushval);
}

uint16_t pull16() {
    uint16_t temp16;
    temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
    sp += 2;
    return(temp16);
}

uint8_t pull8() {
    return (read6502(BASE_STACK + ++sp));
}

void reset6502() {
    pc = ((uint16_t)read6502(0xfffc) | ((uint16_t)read6502(0xfffd) << 8));
    //pc = 0xff00;

    a = 0;
    x = 0;
    y = 0;
    sp = 0xFF;
    status |= FLAG_CONSTANT | FLAG_BREAK;
}


static void (*addrtable[256])();
static void (*optable[256])();
uint8_t penaltyop, penaltyaddr;

//addressing mode functions, calculates effective addresses
static void imp() { //implied
}

static void acc() { //accumulator
}

static void imm() { //immediate
    ea = pc++;
}

static void zp() { //zero-page
    ea = (uint16_t)read6502((uint16_t)pc++);
}

static void zpx() { //zero-page,X
    ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)x) & 0xFF; //zero-page wraparound
}

static void zpy() { //zero-page,Y
    ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
}

static void rel() { //relative for branch ops (8-bit immediate value, sign-extended)
    reladdr = (uint16_t)read6502(pc++);
    if (reladdr & 0x80) reladdr |= 0xFF00;
}

static void abso() { //absolute
    ea = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8);
    pc += 2;
}

static void absx() { //absolute,X
    uint16_t startpage;
    ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
    startpage = ea & 0xFF00;
    ea += (uint16_t)x;

    if (startpage != (ea & 0xFF00)) { //one cycle penlty for page-crossing on some opcodes
        penaltyaddr = 1;
    }

    pc += 2;
}

static void absy() { //absolute,Y
    uint16_t startpage;
    ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
    startpage = ea & 0xFF00;
    ea += (uint16_t)y;

    if (startpage != (ea & 0xFF00)) { //one cycle penlty for page-crossing on some opcodes
        penaltyaddr = 1;
    }

    pc += 2;
}

static void ind() { //indirect
    uint16_t eahelp, eahelp2;
    eahelp = (uint16_t)read6502(pc) | (uint16_t)((uint16_t)read6502(pc+1) << 8);
    eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //replicate 6502 page-boundary wraparound bug
    ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
    pc += 2;
}

static void indx() { // (indirect,X)
    uint16_t eahelp;
    eahelp = (uint16_t)(((uint16_t)read6502(pc++) + (uint16_t)x) & 0xFF); //zero-page wraparound for table pointer
    ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
}

static void indy() { // (indirect),Y
    uint16_t eahelp, eahelp2, startpage;
    eahelp = (uint16_t)read6502(pc++);
    eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //zero-page wraparound
    ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
    startpage = ea & 0xFF00;
    ea += (uint16_t)y;

    if (startpage != (ea & 0xFF00)) { //one cycle penlty for page-crossing on some opcodes
        penaltyaddr = 1;
    }
}

static uint16_t getvalue() {
    if (addrtable[opcode] == acc) return((uint16_t)a);
        else return((uint16_t)read6502(ea));
}

static uint16_t getvalue16() {
    return((uint16_t)read6502(ea) | ((uint16_t)read6502(ea+1) << 8));
}

static void putvalue(uint16_t saveval) {
    if (addrtable[opcode] == acc) a = (uint8_t)(saveval & 0x00FF);
        else write6502(ea, (saveval & 0x00FF));
}


//instruction handler functions


void adc() {
    value = getvalue();

// BCD fix OV 20140915 - adc 
	if ((status & FLAG_DECIMAL)==0) {
    	result = (uint16_t)a + value + (uint16_t)(status & FLAG_CARRY);
   
	    carrycalc(result);
	    zerocalc(result);
 	 	overflowcalc(result, a, value);
  	 	signcalc(result);
	}    
    else // #ifndef NES_CPU
    {	 // Decimal mode
        lxx = (a & 0x0f) + (value & 0x0f) + (uint16_t)(status & FLAG_CARRY);
		if ((lxx & 0xFF) > 0x09)
            lxx += 0x06;
        hxx = (a >> 4) + (value >> 4) + (lxx > 15 ? 1 : 0);
        if ((hxx & 0xff) > 9) 
			hxx += 6;
        result = (lxx & 0x0f);
		result += (hxx << 4); 
        result &= 0xff;
		// deal with carry flag:
		if (hxx>15)
			setcarry();
		else
			clearcarry();
	    zerocalc(result);
    	clearsign();	// negative flag never set for decimal mode.
	    clearoverflow();	// overflow never set for decimal mode.
// end of BCD fix PART 2

        clockticks6502++;
    }
//    #endif // of NES_CPU

    saveaccum(result);
}
/*
static void adc() {
    penaltyop = 1;
    value = getvalue();
    result = (uint16_t)a + value + (uint16_t)(status & FLAG_CARRY);
   
    carrycalc(result);
    zerocalc(result);
    overflowcalc(result, a, value);
    signcalc(result);
   
    saveaccum(result);
}
*/

static void and() {
    penaltyop = 1;
    value = getvalue();
    result = (uint16_t)a & value;
   
    zerocalc(result);
    signcalc(result);
   
    saveaccum(result);
}

static void asl() {
    value = getvalue();
    result = value << 1;

    carrycalc(result);
    zerocalc(result);
    signcalc(result);
   
    putvalue(result);
}

static void bcc() {
    if ((status & FLAG_CARRY) == 0) {
        oldpc = pc;
        pc += reladdr;
        if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
            else clockticks6502++;
    }
}

static void bcs() {
    if ((status & FLAG_CARRY) == FLAG_CARRY) {
        oldpc = pc;
        pc += reladdr;
        if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
            else clockticks6502++;
    }
}

static void beq() {
    if ((status & FLAG_ZERO) == FLAG_ZERO) {
        oldpc = pc;
        pc += reladdr;
        if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
            else clockticks6502++;
    }
}

static void bit() {
    value = getvalue();
    result = (uint16_t)a & value;
   
    zerocalc(result);
    status = (status & 0x3F) | (uint8_t)(value & 0xC0);
}

static void bmi() {
    if ((status & FLAG_SIGN) == FLAG_SIGN) {
        oldpc = pc;
        pc += reladdr;
        if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
            else clockticks6502++;
    }
}

static void bne() {
    if ((status & FLAG_ZERO) == 0) {
        oldpc = pc;
        pc += reladdr;
        if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
            else clockticks6502++;
    }
}

static void bpl() {
    if ((status & FLAG_SIGN) == 0) {
        oldpc = pc;
        pc += reladdr;
        if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
            else clockticks6502++;
    }
}

static void brk() {
    pc++;
    push16(pc); //push next instruction address onto stack
    push8(status | FLAG_BREAK); //push CPU status to stack
    setinterrupt(); //set interrupt flag
    pc = (uint16_t)read6502(0xFFFE) | ((uint16_t)read6502(0xFFFF) << 8);
}

static void bvc() {
    if ((status & FLAG_OVERFLOW) == 0) {
        oldpc = pc;
        pc += reladdr;
        if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
            else clockticks6502++;
    }
}

static void bvs() {
    if ((status & FLAG_OVERFLOW) == FLAG_OVERFLOW) {
        oldpc = pc;
        pc += reladdr;
        if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
            else clockticks6502++;
    }
}

static void clc() {
    clearcarry();
}

static void cld() {
    cleardecimal();
}

static void cli() {
    clearinterrupt();
}

static void clv() {
    clearoverflow();
}

static void cmp() {
    penaltyop = 1;
    value = getvalue();
    result = (uint16_t)a - value;
   
    if (a >= (uint8_t)(value & 0x00FF)) setcarry();
        else clearcarry();
    if (a == (uint8_t)(value & 0x00FF)) setzero();
        else clearzero();
    signcalc(result);
}

static void cpx() {
    value = getvalue();
    result = (uint16_t)x - value;
   
    if (x >= (uint8_t)(value & 0x00FF)) setcarry();
        else clearcarry();
    if (x == (uint8_t)(value & 0x00FF)) setzero();
        else clearzero();
    signcalc(result);
}

static void cpy() {
    value = getvalue();
    result = (uint16_t)y - value;
   
    if (y >= (uint8_t)(value & 0x00FF)) setcarry();
        else clearcarry();
    if (y == (uint8_t)(value & 0x00FF)) setzero();
        else clearzero();
    signcalc(result);
}

static void dec() {
    value = getvalue();
    result = value - 1;
   
    zerocalc(result);
    signcalc(result);
   
    putvalue(result);
}

static void dex() {
    x--;
   
    zerocalc(x);
    signcalc(x);
}

static void dey() {
    y--;
   
    zerocalc(y);
    signcalc(y);
}

static void eor() {
    penaltyop = 1;
    value = getvalue();
    result = (uint16_t)a ^ value;
   
    zerocalc(result);
    signcalc(result);
   
    saveaccum(result);
}

static void inc() {
    value = getvalue();
    result = value + 1;
   
    zerocalc(result);
    signcalc(result);
   
    putvalue(result);
}

static void inx() {
    x++;
   
    zerocalc(x);
    signcalc(x);
}

static void iny() {
    y++;
   
    zerocalc(y);
    signcalc(y);
}

static void jmp() {
    pc = ea;
}

static void jsr() {
    push16(pc - 1);
    pc = ea;
}

static void lda() {
    penaltyop = 1;
    value = getvalue();
    a = (uint8_t)(value & 0x00FF);
   
    zerocalc(a);
    signcalc(a);
}

static void ldx() {
    penaltyop = 1;
    value = getvalue();
    x = (uint8_t)(value & 0x00FF);
   
    zerocalc(x);
    signcalc(x);
}

static void ldy() {
    penaltyop = 1;
    value = getvalue();
    y = (uint8_t)(value & 0x00FF);
   
    zerocalc(y);
    signcalc(y);
}

static void lsr() {
    value = getvalue();
    result = value >> 1;
   
    if (value & 1) setcarry();
        else clearcarry();
    zerocalc(result);
    signcalc(result);
   
    putvalue(result);
}

static void nop() {
    switch (opcode) {
        case 0x1C:
        case 0x3C:
        case 0x5C:
        case 0x7C:
        case 0xDC:
        case 0xFC:
            penaltyop = 1;
            break;
    }
}

static void ora() {
    penaltyop = 1;
    value = getvalue();
    result = (uint16_t)a | value;
   
    zerocalc(result);
    signcalc(result);
   
    saveaccum(result);
}

static void pha() {
    push8(a);
}

static void php() {
    push8(status | FLAG_BREAK);
}

static void pla() {
    a = pull8();
   
    zerocalc(a);
    signcalc(a);
}

static void plp() {
    status = pull8() | FLAG_CONSTANT;
}

static void rol() {
    value = getvalue();
    result = (value << 1) | (status & FLAG_CARRY);
   
    carrycalc(result);
    zerocalc(result);
    signcalc(result);
   
    putvalue(result);
}

static void ror() {
    value = getvalue();
    result = (value >> 1) | ((status & FLAG_CARRY) << 7);
   
    if (value & 1) setcarry();
        else clearcarry();
    zerocalc(result);
    signcalc(result);
   
    putvalue(result);
}

static void rti() {
    status = pull8();
    value = pull16();
    pc = value;
}

static void rts() {
    value = pull16();
    pc = value + 1;
}

void sbc() {
// BCD fix OV 20140915 - adc 
    if ((status & FLAG_DECIMAL)==0) {
	    value = getvalue() ^ 0x00FF;
	    result = (uint16_t)a + value + (uint16_t)(status & FLAG_CARRY);
   
	 	carrycalc(result);
	    zerocalc(result);
	    overflowcalc(result, a, value);
	    signcalc(result);
	}
 	else //   #ifndef NES_CPU
	{ 		// decimal mode
	    value = getvalue();  // Dan: added -1 since all calcs were off by 1
        lxx = (a & 0x0f) - (value & 0x0f) - (uint16_t)((status & FLAG_CARRY)?0:1);  
        if ((lxx & 0x10) != 0) 
			lxx -= 6;
        hxx = (a >> 4) - (value >> 4) - ((lxx & 0x10) != 0 ? 1 : 0);
        if ((hxx & 0x10) != 0) 
			hxx -= 6;
		result = (lxx & 0x0f);
		result += (hxx << 4);
		result = (lxx & 0x0f) | (hxx << 4);
		// deal with carry
		if ((hxx & 0xff) < 15)
			setcarry();			// right? I think so. Intended is   setCarryFlag((hxx & 0xff) < 15);
		else 
			clearcarry();
	    zerocalc(result); // zero dec is zero hex, no problem?
    	clearsign();	// negative flag never set for decimal mode. That's a simplification, see http://www.6502.org/tutorials/decimal_mode.html
	    clearoverflow();	// overflow never set for decimal mode.
		result = result & 0xff;
// end of BCD fix PART 3 (final part)

        clockticks6502++;
    }
     saveaccum(result);
}

    /*
static void sbc() {
    penaltyop = 1;
    value = getvalue() ^ 0x00FF;
    result = (uint16_t)a + value + (uint16_t)(status & FLAG_CARRY);
   
    carrycalc(result);
    zerocalc(result);
    overflowcalc(result, a, value);
    signcalc(result);
   
    saveaccum(result);
}
    */

static void sec() {
    setcarry();
}

static void sed() {
    setdecimal();
}

static void sei() {
    setinterrupt();
}

static void sta() {
    putvalue(a);
}

static void stx() {
    putvalue(x);
}

static void sty() {
    putvalue(y);
}

static void tax() {
    x = a;
   
    zerocalc(x);
    signcalc(x);
}

static void tay() {
    y = a;
   
    zerocalc(y);
    signcalc(y);
}

static void tsx() {
    x = sp;
   
    zerocalc(x);
    signcalc(x);
}

static void txa() {
    a = x;
   
    zerocalc(a);
    signcalc(a);
}

static void txs() {
    sp = x;
}

static void tya() {
    a = y;
   
    zerocalc(a);
    signcalc(a);
}

//undocumented instructions
#ifdef UNDOCUMENTED
    static void lax() {
        lda();
        ldx();
    }

    static void sax() {
        sta();
        stx();
        putvalue(a & x);
        if (penaltyop && penaltyaddr) clockticks6502--;
    }

    static void dcp() {
        dec();
        cmp();
        if (penaltyop && penaltyaddr) clockticks6502--;
    }

    static void isb() {
        inc();
        sbc();
        if (penaltyop && penaltyaddr) clockticks6502--;
    }

    static void slo() {
        asl();
        ora();
        if (penaltyop && penaltyaddr) clockticks6502--;
    }

    static void rla() {
        rol();
        and();
        if (penaltyop && penaltyaddr) clockticks6502--;
    }

    static void sre() {
        lsr();
        eor();
        if (penaltyop && penaltyaddr) clockticks6502--;
    }

    static void rra() {
        ror();
        adc();
        if (penaltyop && penaltyaddr) clockticks6502--;
    }
#else
    #define lax nop
    #define sax nop
    #define dcp nop
    #define isb nop
    #define slo nop
    #define rla nop
    #define sre nop
    #define rra nop
#endif


static void (*addrtable[256])() = {
/*        |  0  |  1  |  2  |  3  |  4  |  5  |  6  |  7  |  8  |  9  |  A  |  B  |  C  |  D  |  E  |  F  |     */
/* 0 */     imp, indx,  imp, indx,   zp,   zp,   zp,   zp,  imp,  imm,  acc,  imm, abso, abso, abso, abso, /* 0 */
/* 1 */     rel, indy,  imp, indy,  zpx,  zpx,  zpx,  zpx,  imp, absy,  imp, absy, absx, absx, absx, absx, /* 1 */
/* 2 */    abso, indx,  imp, indx,   zp,   zp,   zp,   zp,  imp,  imm,  acc,  imm, abso, abso, abso, abso, /* 2 */
/* 3 */     rel, indy,  imp, indy,  zpx,  zpx,  zpx,  zpx,  imp, absy,  imp, absy, absx, absx, absx, absx, /* 3 */
/* 4 */     imp, indx,  imp, indx,   zp,   zp,   zp,   zp,  imp,  imm,  acc,  imm, abso, abso, abso, abso, /* 4 */
/* 5 */     rel, indy,  imp, indy,  zpx,  zpx,  zpx,  zpx,  imp, absy,  imp, absy, absx, absx, absx, absx, /* 5 */
/* 6 */     imp, indx,  imp, indx,   zp,   zp,   zp,   zp,  imp,  imm,  acc,  imm,  ind, abso, abso, abso, /* 6 */
/* 7 */     rel, indy,  imp, indy,  zpx,  zpx,  zpx,  zpx,  imp, absy,  imp, absy, absx, absx, absx, absx, /* 7 */
/* 8 */     imm, indx,  imm, indx,   zp,   zp,   zp,   zp,  imp,  imm,  imp,  imm, abso, abso, abso, abso, /* 8 */
/* 9 */     rel, indy,  imp, indy,  zpx,  zpx,  zpy,  zpy,  imp, absy,  imp, absy, absx, absx, absy, absy, /* 9 */
/* A */     imm, indx,  imm, indx,   zp,   zp,   zp,   zp,  imp,  imm,  imp,  imm, abso, abso, abso, abso, /* A */
/* B */     rel, indy,  imp, indy,  zpx,  zpx,  zpy,  zpy,  imp, absy,  imp, absy, absx, absx, absy, absy, /* B */
/* C */     imm, indx,  imm, indx,   zp,   zp,   zp,   zp,  imp,  imm,  imp,  imm, abso, abso, abso, abso, /* C */
/* D */     rel, indy,  imp, indy,  zpx,  zpx,  zpx,  zpx,  imp, absy,  imp, absy, absx, absx, absx, absx, /* D */
/* E */     imm, indx,  imm, indx,   zp,   zp,   zp,   zp,  imp,  imm,  imp,  imm, abso, abso, abso, abso, /* E */
/* F */     rel, indy,  imp, indy,  zpx,  zpx,  zpx,  zpx,  imp, absy,  imp, absy, absx, absx, absx, absx  /* F */
};

static void (*optable[256])() = {
/*        |  0  |  1  |  2  |  3  |  4  |  5  |  6  |  7  |  8  |  9  |  A  |  B  |  C  |  D  |  E  |  F  |      */
/* 0 */      brk,  ora,  nop,  slo,  nop,  ora,  asl,  slo,  php,  ora,  asl,  nop,  nop,  ora,  asl,  slo, /* 0 */
/* 1 */      bpl,  ora,  nop,  slo,  nop,  ora,  asl,  slo,  clc,  ora,  nop,  slo,  nop,  ora,  asl,  slo, /* 1 */
/* 2 */      jsr,  and,  nop,  rla,  bit,  and,  rol,  rla,  plp,  and,  rol,  nop,  bit,  and,  rol,  rla, /* 2 */
/* 3 */      bmi,  and,  nop,  rla,  nop,  and,  rol,  rla,  sec,  and,  nop,  rla,  nop,  and,  rol,  rla, /* 3 */
/* 4 */      rti,  eor,  nop,  sre,  nop,  eor,  lsr,  sre,  pha,  eor,  lsr,  nop,  jmp,  eor,  lsr,  sre, /* 4 */
/* 5 */      bvc,  eor,  nop,  sre,  nop,  eor,  lsr,  sre,  cli,  eor,  nop,  sre,  nop,  eor,  lsr,  sre, /* 5 */
/* 6 */      rts,  adc,  nop,  rra,  nop,  adc,  ror,  rra,  pla,  adc,  ror,  nop,  jmp,  adc,  ror,  rra, /* 6 */
/* 7 */      bvs,  adc,  nop,  rra,  nop,  adc,  ror,  rra,  sei,  adc,  nop,  rra,  nop,  adc,  ror,  rra, /* 7 */
/* 8 */      nop,  sta,  nop,  sax,  sty,  sta,  stx,  sax,  dey,  nop,  txa,  nop,  sty,  sta,  stx,  sax, /* 8 */
/* 9 */      bcc,  sta,  nop,  nop,  sty,  sta,  stx,  sax,  tya,  sta,  txs,  nop,  nop,  sta,  nop,  nop, /* 9 */
/* A */      ldy,  lda,  ldx,  lax,  ldy,  lda,  ldx,  lax,  tay,  lda,  tax,  nop,  ldy,  lda,  ldx,  lax, /* A */
/* B */      bcs,  lda,  nop,  lax,  ldy,  lda,  ldx,  lax,  clv,  lda,  tsx,  lax,  ldy,  lda,  ldx,  lax, /* B */
/* C */      cpy,  cmp,  nop,  dcp,  cpy,  cmp,  dec,  dcp,  iny,  cmp,  dex,  nop,  cpy,  cmp,  dec,  dcp, /* C */
/* D */      bne,  cmp,  nop,  dcp,  nop,  cmp,  dec,  dcp,  cld,  cmp,  nop,  dcp,  nop,  cmp,  dec,  dcp, /* D */
/* E */      cpx,  sbc,  nop,  isb,  cpx,  sbc,  inc,  isb,  inx,  sbc,  nop,  sbc,  cpx,  sbc,  inc,  isb, /* E */
/* F */      beq,  sbc,  nop,  isb,  nop,  sbc,  inc,  isb,  sed,  sbc,  nop,  isb,  nop,  sbc,  inc,  isb  /* F */
};

static const uint8_t ticktable[256] = {
/*        |  0  |  1  |  2  |  3  |  4  |  5  |  6  |  7  |  8  |  9  |  A  |  B  |  C  |  D  |  E  |  F  |     */
/* 0 */      7,    6,    2,    8,    3,    3,    5,    5,    3,    2,    2,    2,    4,    4,    6,    6,  /* 0 */
/* 1 */      2,    5,    2,    8,    4,    4,    6,    6,    2,    4,    2,    7,    4,    4,    7,    7,  /* 1 */
/* 2 */      6,    6,    2,    8,    3,    3,    5,    5,    4,    2,    2,    2,    4,    4,    6,    6,  /* 2 */
/* 3 */      2,    5,    2,    8,    4,    4,    6,    6,    2,    4,    2,    7,    4,    4,    7,    7,  /* 3 */
/* 4 */      6,    6,    2,    8,    3,    3,    5,    5,    3,    2,    2,    2,    3,    4,    6,    6,  /* 4 */
/* 5 */      2,    5,    2,    8,    4,    4,    6,    6,    2,    4,    2,    7,    4,    4,    7,    7,  /* 5 */
/* 6 */      6,    6,    2,    8,    3,    3,    5,    5,    4,    2,    2,    2,    5,    4,    6,    6,  /* 6 */
/* 7 */      2,    5,    2,    8,    4,    4,    6,    6,    2,    4,    2,    7,    4,    4,    7,    7,  /* 7 */
/* 8 */      2,    6,    2,    6,    3,    3,    3,    3,    2,    2,    2,    2,    4,    4,    4,    4,  /* 8 */
/* 9 */      2,    6,    2,    6,    4,    4,    4,    4,    2,    5,    2,    5,    5,    5,    5,    5,  /* 9 */
/* A */      2,    6,    2,    6,    3,    3,    3,    3,    2,    2,    2,    2,    4,    4,    4,    4,  /* A */
/* B */      2,    5,    2,    5,    4,    4,    4,    4,    2,    4,    2,    4,    4,    4,    4,    4,  /* B */
/* C */      2,    6,    2,    8,    3,    3,    5,    5,    2,    2,    2,    2,    4,    4,    6,    6,  /* C */
/* D */      2,    5,    2,    8,    4,    4,    6,    6,    2,    4,    2,    7,    4,    4,    7,    7,  /* D */
/* E */      2,    6,    2,    8,    3,    3,    5,    5,    2,    2,    2,    2,    4,    4,    6,    6,  /* E */
/* F */      2,    5,    2,    8,    4,    4,    6,    6,    2,    4,    2,    7,    4,    4,    7,    7   /* F */
};


void nmi6502() {
    push16(pc);
    push8(status);
    status |= FLAG_INTERRUPT;
    pc = (uint16_t)read6502(0xFFFA) | ((uint16_t)read6502(0xFFFB) << 8);
}

uint16_t getPC() {
    return pc;
}

void irq6502() {
    push16(pc);
    push8(status);
    status |= FLAG_INTERRUPT;
    pc = (uint16_t)read6502(0xFFFE) | ((uint16_t)read6502(0xFFFF) << 8);
}

uint8_t callexternal = 0;
void (*loopexternal)();

void exec6502(uint32_t tickcount) {
    clockgoal6502 += tickcount;
   
    while (clockticks6502 < clockgoal6502) {
        opcode = read6502(pc++);
        status |= FLAG_CONSTANT;

        penaltyop = 0;
        penaltyaddr = 0;

        (*addrtable[opcode])();
        (*optable[opcode])();
        clockticks6502 += ticktable[opcode];
        if (penaltyop && penaltyaddr) clockticks6502++;
    }

}

void step6502() {
    opcode = read6502(pc++);
    status |= FLAG_CONSTANT;
    
    // Dan Edit Start
    //save tick target to comparator Ctl Reg
    Cmp_Cycles_Write(ticktable[opcode]);
    // Enable the tick counter
    Start_Clock_Write(1);
    Start_Clock_Write(0);
    // Dan Edit End
    
    penaltyop = 0;
    penaltyaddr = 0;

    (*addrtable[opcode])();
    (*optable[opcode])();
    clockticks6502 += ticktable[opcode];
    if (penaltyop && penaltyaddr) clockticks6502++;
    clockgoal6502 = clockticks6502;
    
    // Dan Edit Start
    //wait for cycles to complete
    //while(Status_Reg_Cycles_Read() == 0){}
    // Dan Edit
    
    //if (callexternal) (*loopexternal)();
    
}

// Interrupt handler for Counter_002 isr
CY_ISR(Count_002_Handler)
{
    Freq_Select_002_Write(0);           // Change clock divider to x1
    RIOT_002.CLKRDI = 0x80;             // Set bit 7 of zero passed flag
    Counter_002_ReadStatusRegister();   // clear interrupt
}

// Interrupt handler for Counter_003 isr
CY_ISR(Count_003_Handler)
{
    Freq_Select_003_Write(0);           // Change clock divider to x1
    RIOT_003.CLKRDI = 0x80;             // Set bit 7 of zero passed flag
    Counter_003_ReadStatusRegister();   // clear interrupt
}

// Interrupt handler for segment speed
CY_ISR(Count_segspeed_Handler)
{
    speedflag = 1;
}

uint8 kdata = 0x15;         // data from touch screen display
uint8 sst_status = 0;       //0 = SST OFF, 255 = SST ON
uint8 const tempcount[] = {0x12,0x10,0x0E,0x0C,0x0A,0x08};
int tempint1 = 0;
int tempint2 = 0;
int tempint3 = 0;

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    LED_1_Write(1);
    Control_Reg_Serial_Select_Write(0);
    UART_Display_Start();
    UART_PC_Start();
    UART_Display_ClearTxBuffer();
    UART_Display_ClearRxBuffer();
    UART_PC_ClearTxBuffer();
    UART_PC_ClearRxBuffer();
    isr_002_StartEx(Count_002_Handler);     // Start Counter_002 int handler
    isr_003_StartEx(Count_003_Handler);     // Start Counter_003 int handler
    isr_segments_StartEx(Count_segspeed_Handler); // Start segment speed int handler
    Clock_CPU_Start();
    Clock_Sample_Start();
    Counter_002_Start();
    Counter_003_Start();
    Count7_1_Start();
    CyDelay(2000);
    
     int t;
    // Clear User RAM
    for(t=0; t<5120; t++) {
        RAM_User[t] = 0;
    }
    
    // Clear 6530 RAM
    for(t=0; t<128; t++) {
        RAM_6530[t] = 0;
    }
    
    // Clear expansion RAM
    for(t=0; t<(32*1024); t++) {
        RAM_User_Expand[t] = 0x00;
    }
    
    // Clear Data Lines
    RIOT_002.SAD = 0;       // Clear A Data
    RIOT_002.PADD = 0;      // Clear A Data direction reg
    RIOT_002.SBD = 0;       // Clear B Data 
    RIOT_002.PBDD = 0;      // Clear B Data direction reg
    RIOT_002.CLKRDI = 0;
    
    //UART_PC_PutString("KIM-1 EMULATOR");
    
    LED_1_Write(0);
    
    // Test Segments
    uint8 tempcount1 = 1;
    uint8 tempcount2 = 0;
    uint8 tempcount3 = 0;
    Control_Reg_6530_002_PA_Write(0xff);
    for(tempcount3=0; tempcount3<6; tempcount3++) {
        for(tempcount2=0; tempcount2<7; tempcount2++){
            Control_Reg_6530_002_PA_Write(tempcount1);
            Control_Reg_LED_Key_Write(tempcount[tempcount3]);
            CyDelay(100);
            tempcount1 = (tempcount1 << 1) | 0x01;
        }
        tempcount1 = 1;
    }
    
    // Reset KIM and start on reset
    reset6502();
    
    for(;;)
    {
        /* Place your application code here. */
        step6502();
        // check if getting a key from keyboard
        // This wedges the GETKEY subroutine
        if(pc == 0x1F6A) {
            a = kdata;      // place key in A
            rts();
        }
        // Check for char out
        else if(pc == 0x1EA0) {
            UART_PC_PutChar(a);
            pc = 0x1ED3;
            rts();
        }
         // Check for char in
        else if(pc == 0x1E5A) {
            a = UART_PC_GetChar();  // place char in A
            if(a == '~') {
                // Load from serial
                a = 0;
                UART_PC_PutString("\r\nSend Over Serial\r\n");
                // Get start and end addresses
                while(~UART_PC_ReadRxStatus() & UART_PC_RX_STS_FIFO_NOTEMPTY){}
                tempint1 = UART_PC_ReadRxData();
                while(~UART_PC_ReadRxStatus() & UART_PC_RX_STS_FIFO_NOTEMPTY){}
                tempint1 = (tempint1 << 8) | UART_PC_ReadRxData();
                while(~UART_PC_ReadRxStatus() & UART_PC_RX_STS_FIFO_NOTEMPTY){}
                tempint2 = UART_PC_ReadRxData();
                while(~UART_PC_ReadRxStatus() & UART_PC_RX_STS_FIFO_NOTEMPTY){}
                tempint2 = (tempint2 << 8) | UART_PC_ReadRxData();
                // Calculate number of bytes
                tempint3 = tempint2 - tempint1 + 1;
                // Get all bytes
                for(tempint2=0; tempint2<tempint3; tempint2++){
                    while(~UART_PC_ReadRxStatus() & UART_PC_RX_STS_FIFO_NOTEMPTY){}
                    //UART_PC_PutChar(UART_PC_ReadRxData());
                    if(tempint1 < 0x1400) {
                        RAM_User[tempint1++] = UART_PC_ReadRxData();
                    }
                    else if(tempint1 > 0x1FFF) {
                        RAM_User_Expand[tempint1 - 0x2000] = UART_PC_ReadRxData();
                        tempint1 += 1;
                    }
                    else if(tempint1 > 0x177F) {
                        RAM_6530[tempint1 - 0x1780] = UART_PC_ReadRxData();
                        tempint1 += 1;
                    }
                }
                UART_PC_PutString("\r\nSend Over Serial Complete\r\n");
            }
            pc = 0x1E87;
        }
        // Check for keypress from display
        // 0x15 = no key being pressed
        // Otherwise value of key is placed in 'kdata'
        if(UART_Display_ReadRxStatus() & UART_Display_RX_STS_FIFO_NOTEMPTY) {
            kdata = UART_Display_ReadRxData();
            // Check for GO key
            if(kdata == 19) {
                // Check for SST ON
                if(sst_status == 255) {
                    pc = RAM_User[0xFB];        // load POINTH into PC
                    pc = pc << 8;               // shift into high byte
                    pc = pc | RAM_User[0xFA];   // load POINTL into PC low byte
                    step6502();
                    nmi6502();
                    Control_Reg_Keyboard_Write(0xFF);
                }
                else{
                Control_Reg_Keyboard_Write(0xDF);
                }
            }
            // Check for Reset
            else if(kdata == 'R'){
                reset6502();
                Control_Reg_Keyboard_Write(0xFF);
            }
            // Check for Stop
            else if(kdata == 'S'){
                nmi6502();
                Control_Reg_Keyboard_Write(0xFF);
            }
            // Check for SST
            else if(kdata == 'Y'){
                sst_status = ~sst_status;
                Control_Reg_Keyboard_Write(0xFF);
            }
            // Check for UARt CONFIG
            else if(kdata == 'X'){
                Display_UART_Config();
            }
            // These lines of code needed for TTYKB subroutine
            // Before GETKEY is called PA is checked to see if a key is presssed
            // 0x15 = no key pressed
            else if(kdata != 0x15){
                Control_Reg_Keyboard_Write(0xDF);   // any value will do as long as PA0=1
            }
            else Control_Reg_Keyboard_Write(0xFF);
        }
        
        // Dan Edit Start
        //wait for cycles to complete
        while(Status_Reg_Cycles_Read() == 0){}     // <------- uncomment for KIM to work!!!!!!
        // Dan Edit
    }
}
    
uint8 read6502(uint16_t address){
    uint t;
    uint8 u;
    // Check if reading from USER RAM
    if(address < 5120) {
        return RAM_User[address];
    }
    // Check if reading dead space
    //if(address < 0x1700) {
    //    return 0;
    //}
    // Check if reading 6530
    if(address < 0x1800) {
        // Check if reading 6530 I/O or timers
        if(address < 0x1780) {
            // Check if 6530-003
            if(address < 0x1740) {
                if(address == 0x1704 || address == 0x1706) {
                    // Get current timer count
                        u = Counter_003_ReadCounter();
                        t = RIOT_003.CLKRDT;                        // get current timer count
                        if(RIOT_003.CLKRDI == 1) {                  // check if timer passed 0
                            Freq_Select_003_Write(RIOT_003.PCLK);   // clk div back to previous setting
                        }
                        return u;     // return current timer count
                }
                //else if(address == 0x1705) {
                 //   return RIOT_003.CLK8T;
                //}
                //else if(address == 0x1707) {
                 //   return RIOT_003.CLKRDI;
                //}
                switch(address) {
                    case 0x1705:
                        return RIOT_003.CLK8T;
                    case 0x1707:
                        return RIOT_003.CLKRDI;
                    }
                return 0;
            }
            // Must be 6530-002
            if(address == 0x1744 || address == 0x1746) {
                 // Get current timer count
                u = Counter_002_ReadCounter();
                //t = RIOT_002.CLKRDT;                        // get current timer count
                if(RIOT_002.CLKRDI == 1) {                  // check if timer passed 0
                    Freq_Select_002_Write(RIOT_002.PCLK);   // clk div back to previous setting
                }
                return u;     // return current timer count
            }
            
            switch(address) {
                case 0x1740:
                    // A DATA
                    return Status_Reg_6530_002_PA_Read();
                case 0x1741:
                    return 0; //Control_Reg_6530_002_DDR_A_Read();
                case 0x1742:
                    return RIOT_002.SBD;
                case 0x1743:
                    return RIOT_002.PBDD;
                case 0x1745:
                    return RIOT_002.CLK8T;
                case 0x1747:
                    return RIOT_002.CLKRDI;
            }
        }
        // Reading 6530 RAM
        //t = address - 0x1780;
        return RAM_6530[address - 0x1780];
    }
    // Check if reading 6530 ROMs
    if(address < 0x2000) {
        //t = address - 0x1800;
        return ROM[address - 0x1800];
    }
    // Check Expansion RAM (32K)
    if(address < 0xA000){
        // read from expansion RAM
        //t = address - 0x2000;
        return RAM_User_Expand[address - 0x2000];
    }
    // Check expansion RAM
    if(address <= 0xFFFF) {
        // Check if reading interrupt vectors
        if(address > 0xFFF9)
        {
            // NMI
            if(address == 0xFFFA) {
                return 0x00;
            }
            if(address == 0xFFFB) {
                return 0x1C;
            }
            // RST
            if(address == 0xFFFC) {
                return 0x22;
            }
            if(address == 0xFFFD) {
                return 0x1C;
            }
            // IRQ
            if(address == 0xFFFE) {
                return 0x00;
            }
            if(address == 0xFFFF) {
                return 0x1C;
            }
        }
    }
    return 0;
}


void write6502(uint16_t address, uint8_t value) {
    int t = 0;
    // Check if writing to from USER RAM
    if(address < 5120) {
        RAM_User[address] = value;
        return;
    }
    // Check if writing to dead space
    //if(address < 0x1700) {
    //    return;
    //}
    // Check if writing to 6530
    if(address < 0x1800) {
        // Check if writing to 6530 I/O or timers
        if(address < 0x1780) {
            // Check if 6530-003
            if(address < 0x1740) {
                switch(address) {
                    case 0x1700:
                        // A DATA
                        break;
                    case 0x1701:
                        // A DATA DIRECTION
                        RIOT_003.PADD = value;
                        break;
                    case 0x1702:
                        // B DATA
                        RIOT_003.SBD = value;
                        break;
                    case 0x1703:
                        // B DATA DIRECTION
                        RIOT_003.PBDD = value;
                        break;
                    case 0x1704:
                        // Set and start timer freq x1
                        Counter_003_Stop();
                        Counter_003_WriteCounter(value);    // Write new value into counter
                        Freq_Select_003_Write(0);           // Change clock div to x1
                        RIOT_003.CLKRDI = 0;                // Reset passed 0 flag
                        RIOT_003.PCLK = 0;                  // CLK freq = x1
                        Counter_003_Start();
                        break;
                    case 0x1705:
                        // Set and start timer freq x8
                        Counter_003_Stop();
                        Counter_003_WriteCounter(value);    // Write new value into counter
                        Freq_Select_003_Write(1);           // Change clock div to x8 
                        RIOT_003.CLKRDI = 0;                // Reset passed 0 flag
                        RIOT_003.PCLK = 1;                  // CLK freq = x8
                        Counter_003_Start();
                        break;
                    case 0x1706:
                        // Set and start timer freq x64
                        Counter_003_Stop();
                        Counter_003_WriteCounter(value);    // Write new value into counter
                        Freq_Select_003_Write(2);           // Change clock div to x64 
                        RIOT_003.CLKRDI = 0;                // Reset passed 0 flag
                        RIOT_003.PCLK = 2;                  // CLK freq = x64
                        Counter_003_Start();
                        break;
                    case 0x1707:
                        // Set and start timer freq x1024
                        Counter_003_Stop();
                        Counter_003_WriteCounter(value);    // Write new value into counter
                        Freq_Select_003_Write(3);           // Change clock div to x1024
                        RIOT_003.CLKRDI = 0;                // Reset passed 0 flag
                        RIOT_003.PCLK = 3;                  // CLK freq = x1024
                        Counter_003_Start();
                        break;
                }
                return;
            }
            // Must be 6530-002
            switch(address) {
                case 0x1740:
                    // A DATA
                    Control_Reg_6530_002_PA_Write(value);
                    break;
                case 0x1741:
                    // A DATA DIRECTION
                    //Control_Reg_6530_002_DDR_A_Write(value);
                    break;
                case 0x1742:
                    //REG_TTY_OUT_Write(value);       // send bit to TTY
                    Control_Reg_LED_Key_Write(value);
                    RIOT_002.SBD = value;               // save value in Data B
                    break;
                case 0x1743:
                    RIOT_002.PBDD = value;
                    break;
                case 0x1744:
                    // Set and start timer freq x1
                    RIOT_002.PCLK = 0;                  // CLK freq = x1
                    Counter_002_Stop();
                    Counter_002_WriteCounter(value);    // Write new value into counter
                    Freq_Select_002_Write(0);           // Change clock div to x1
                    RIOT_002.CLKRDI = 0;                // Reset passed 0 flag
                    Counter_002_Start();
                    break;
                case 0x1745:
                    // Set and start timer freq x8
                    RIOT_002.PCLK = 1;                  // CLK freq = x8
                    Counter_002_Stop();
                    Counter_002_WriteCounter(value);    // Write new value into counter
                    Freq_Select_002_Write(1);           // Change clock div to x8 
                    RIOT_002.CLKRDI = 0;                // Reset passed 0 flag
                    Counter_002_Start();
                    break;
                case 0x1746:
                    // Set and start timer freq x64
                    RIOT_002.PCLK = 2;                  // CLK freq = x64
                    Counter_002_Stop();
                    Counter_002_WriteCounter(value);    // Write new value into counter
                    Freq_Select_002_Write(2);           // Change clock div to x64 
                    RIOT_002.CLKRDI = 0;                // Reset passed 0 flag
                    Counter_002_Start();
                    break;
                case 0x1747:
                    // Set and start timer freq x1024
                    RIOT_002.PCLK = 3;                  // CLK freq = x1024
                    Counter_002_Stop();
                    Counter_002_WriteCounter(value);    // Write new value into counter
                    Freq_Select_002_Write(3);           // Change clock div to x1024
                    RIOT_002.CLKRDI = 0;                // Reset passed 0 flag
                    Counter_002_Start();
            }
            return;
        }
        // Writing to 6530 RAM
        //t = address - 0x1780;
        RAM_6530[address - 0x1780] = value;
    }
    // Check expansion RAM
    if(address < 0xA000 && address > 0x1FFF) {
        //t = address - 0x2000;
        RAM_User_Expand[address - 0x2000] = value;
    }
        
}

// This function handles UART Config mode
// Since comms to Display UART are disabled...
// must reset PSOC to get back into KIM mode
void Display_UART_Config() {
    int8 ww = 0;
    uint8 xx = 0;
    uint8 yy = 0;
    int8 end_position = 0;
    uint8 tempmessg[6] = {255,255,255,255,255,255};
    // Switch arrows on screen
    UART_Display_PutString("vis p4,0\xFF\xFF\xFF");
    UART_Display_PutString("vis p5,0\xFF\xFF\xFF");
    UART_Display_PutString("vis p3,1\xFF\xFF\xFF");
    UART_Display_PutString("vis b1,0\xFF\xFF\xFF");
    UART_Display_PutString("vis b0,0\xFF\xFF\xFF");
    TxWaitForCharUART();
    
    // Flip the UART switch over to Dipsplay<>PC
    Control_Reg_Serial_Select_Write(1);
    // Turn off LEDs
    Control_Reg_6530_002_PA_Write(0xff);
    Control_Reg_LED_Key_Write(0xff);
    ww = 0; // length of original message string
    end_position = 0;
    for(;;) {
        // Fill string buffer with 6 digit window
        ww = end_position - 5;
        for(xx=0; xx < 6; xx++) {
            // check for leading blank segments
            if(ww < 0) {
                tempmessg[xx] = 0;
            }
            // Check for space char
            else {
                if(UART_Message[ww] == ' ') {
                    tempmessg[xx] = 0;
                }
                // place char in buffer
                else {
                    tempmessg[xx] = Display_Chars[UART_Message[ww]-65];
                }
            }
            // check for trailing blank segments
            if(ww > 10) {
                tempmessg[xx] = 0;
            }
            ww += 1;
        }
        end_position += 1;
        // check string pointer is overshooting string
        // wanted for traling blank segments (but not more)
        if(end_position > 10+6) {
            end_position = 0;
            ww = end_position - 5;
        }
        
/*         
        for(xx=0; xx < 6; xx++) {
            UART_PC_PutChar(tempmessg[xx]);
        }
        CyDelay(2000);
*/
        
        // Send buffer to display
        yy = 5;
        speedflag = 0;                      // reset counter ISR flag
        Count7_1_WritePeriod(15);              // set display hang time
        Control_Reg_Segment_Speed_Write(1);     // reset counter (starts counting)
        Control_Reg_Segment_Speed_Write(0);
        // Display the message on 7 segment display
        while(speedflag == 0) {
            for(xx = 0; xx < 6; xx++) {
                Control_Reg_6530_002_PA_Write(tempmessg[xx]);
                Control_Reg_LED_Key_Write(tempcount[yy]);
                yy--;
                CyDelay(3);
            }
        yy = 5;
        }
    }
}

// Waits for UART buffer clear
void TxWaitForCharUART()
{
	uint8 status;
	do
	{
		status = UART_Display_ReadTxStatus();
	}
	while (~status & UART_Display_TX_STS_FIFO_EMPTY);
}

/* [] END OF FILE */