/*******************************************************************************
* File Name: Freq_Select_003_PM.c
* Version 1.80
*
* Description:
*  This file contains the setup, control, and status commands to support 
*  the component operation in the low power mode. 
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "Freq_Select_003.h"

/* Check for removal by optimization */
#if !defined(Freq_Select_003_Sync_ctrl_reg__REMOVED)

static Freq_Select_003_BACKUP_STRUCT  Freq_Select_003_backup = {0u};

    
/*******************************************************************************
* Function Name: Freq_Select_003_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Freq_Select_003_SaveConfig(void) 
{
    Freq_Select_003_backup.controlState = Freq_Select_003_Control;
}


/*******************************************************************************
* Function Name: Freq_Select_003_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*
*******************************************************************************/
void Freq_Select_003_RestoreConfig(void) 
{
     Freq_Select_003_Control = Freq_Select_003_backup.controlState;
}


/*******************************************************************************
* Function Name: Freq_Select_003_Sleep
********************************************************************************
*
* Summary:
*  Prepares the component for entering the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Freq_Select_003_Sleep(void) 
{
    Freq_Select_003_SaveConfig();
}


/*******************************************************************************
* Function Name: Freq_Select_003_Wakeup
********************************************************************************
*
* Summary:
*  Restores the component after waking up from the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Freq_Select_003_Wakeup(void)  
{
    Freq_Select_003_RestoreConfig();
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
