/*******************************************************************************
* File Name: Start_Clock.h  
* Version 1.80
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CONTROL_REG_Start_Clock_H) /* CY_CONTROL_REG_Start_Clock_H */
#define CY_CONTROL_REG_Start_Clock_H

#include "cyfitter.h"

#if ((CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3) || \
     (CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC4) || \
     (CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC5))
    #include "cytypes.h"
#else
    #include "syslib/cy_syslib.h"
#endif

    
/***************************************
*     Data Struct Definitions
***************************************/

/* Sleep Mode API Support */
typedef struct
{
    uint8 controlState;

} Start_Clock_BACKUP_STRUCT;


/***************************************
*         Function Prototypes 
***************************************/

void    Start_Clock_Write(uint8 control) ;
uint8   Start_Clock_Read(void) ;

void Start_Clock_SaveConfig(void) ;
void Start_Clock_RestoreConfig(void) ;
void Start_Clock_Sleep(void) ; 
void Start_Clock_Wakeup(void) ;


/***************************************
*            Registers        
***************************************/

/* Control Register */
#define Start_Clock_Control        (* (reg8 *) Start_Clock_Sync_ctrl_reg__CONTROL_REG )
#define Start_Clock_Control_PTR    (  (reg8 *) Start_Clock_Sync_ctrl_reg__CONTROL_REG )

#endif /* End CY_CONTROL_REG_Start_Clock_H */


/* [] END OF FILE */
