/*******************************************************************************
* File Name: Counter_002_PM.c  
* Version 3.0
*
*  Description:
*    This file provides the power management source code to API for the
*    Counter.  
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "Counter_002.h"

static Counter_002_backupStruct Counter_002_backup;


/*******************************************************************************
* Function Name: Counter_002_SaveConfig
********************************************************************************
* Summary:
*     Save the current user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Counter_002_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void Counter_002_SaveConfig(void) 
{
    #if (!Counter_002_UsingFixedFunction)

        Counter_002_backup.CounterUdb = Counter_002_ReadCounter();

        #if(!Counter_002_ControlRegRemoved)
            Counter_002_backup.CounterControlRegister = Counter_002_ReadControlRegister();
        #endif /* (!Counter_002_ControlRegRemoved) */

    #endif /* (!Counter_002_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Counter_002_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Counter_002_backup:  Variables of this global structure are used to 
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Counter_002_RestoreConfig(void) 
{      
    #if (!Counter_002_UsingFixedFunction)

       Counter_002_WriteCounter(Counter_002_backup.CounterUdb);

        #if(!Counter_002_ControlRegRemoved)
            Counter_002_WriteControlRegister(Counter_002_backup.CounterControlRegister);
        #endif /* (!Counter_002_ControlRegRemoved) */

    #endif /* (!Counter_002_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Counter_002_Sleep
********************************************************************************
* Summary:
*     Stop and Save the user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Counter_002_backup.enableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void Counter_002_Sleep(void) 
{
    #if(!Counter_002_ControlRegRemoved)
        /* Save Counter's enable state */
        if(Counter_002_CTRL_ENABLE == (Counter_002_CONTROL & Counter_002_CTRL_ENABLE))
        {
            /* Counter is enabled */
            Counter_002_backup.CounterEnableState = 1u;
        }
        else
        {
            /* Counter is disabled */
            Counter_002_backup.CounterEnableState = 0u;
        }
    #else
        Counter_002_backup.CounterEnableState = 1u;
        if(Counter_002_backup.CounterEnableState != 0u)
        {
            Counter_002_backup.CounterEnableState = 0u;
        }
    #endif /* (!Counter_002_ControlRegRemoved) */
    
    Counter_002_Stop();
    Counter_002_SaveConfig();
}


/*******************************************************************************
* Function Name: Counter_002_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Counter_002_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Counter_002_Wakeup(void) 
{
    Counter_002_RestoreConfig();
    #if(!Counter_002_ControlRegRemoved)
        if(Counter_002_backup.CounterEnableState == 1u)
        {
            /* Enable Counter's operation */
            Counter_002_Enable();
        } /* Do nothing if Counter was disabled before */    
    #endif /* (!Counter_002_ControlRegRemoved) */
    
}


/* [] END OF FILE */
